import socket

# Bind the socket to a specific address and port
#host = "0.0.0.0"    # Listen on ALL network interfaces
host = '120.96.143.126'   # Use localhost ONLY
port = 12345         # Choose any available port
max_queued = 50      # Maximum number of queued connections

# Create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
address = (host, port)
server_socket.bind(address)

# Listen for incoming connections
server_socket.listen(max_queued)

print(f"Server listening on {host}:{port}")

# Initialize a client counter
client_counter = 0

while True:
    # Accept incoming connections
    client_socket, client_address = server_socket.accept()

    print(f"Accepted connection from {client_address}")

    # Increase the client counter and assign the ID
    client_counter += 1

    # Send the client ID as a response
    client_socket.send(f"Your ID is {client_counter}".encode())

    # Receive data from the client
    data = client_socket.recv(1024)  # 1024 is the buffer size
    message = data.decode()

    print(f"Received from client {client_counter}: {message}")

    # Close the socket for this client
    client_socket.close()

    # To quit if message is empty
    if not message:
        break