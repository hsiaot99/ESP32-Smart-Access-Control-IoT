const https = require('https');

const options = {
  hostname: 'wic.heo.taipei',
  port: 443,
  path: '/OpenData/API/Water/Get?stationNo=&loginId=river&dataKey=9E2648AA',
  method: 'GET'
};

const req = https.request(options, res => {
  let data = '';

  console.log(`Status Code: ${res.statusCode}`);

  res.on('data', chunk => {
    data += chunk;
  });

  res.on('end', () => {
    try {
      const info = JSON.parse(data);
      console.log(`\nTotal Count: ${info.count}`);
      console.log('Sample data [1]:', info.data[1]);
      console.log('Sample data [5]:', info.data[5]);
      console.log('Station Name at index 5:', info.data[5].stationName);
    } catch (err) {
      console.error('Error parsing JSON:', err.message);
    }
  });
});

req.on('error', error => {
  console.error('Request error:', error.message);
});

req.end();
