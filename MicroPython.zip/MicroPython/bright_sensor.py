from machine import ADC
import time

gpio = 34
a = ADC(gpio)

while True:
    v = a.read()
    u16 = a.read_u16()  # read a raw analog value in the range 0-65535
    uv = a.read_uv()   # read an analog value in microvolts
    print(f"Pin_{gpio}: {v}, u16:{u16}, uv:{uv}")
    time.sleep(1)