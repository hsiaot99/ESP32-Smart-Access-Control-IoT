from machine import Timer
import time

# Define a global dictionary to track counts for each job
count_dict = {}

# Define a function for the timer callback
def timer_thread(timer, thread_name, delay):
    count = count_dict.get(thread_name, 0) + 1
    count_dict[thread_name] = count
    print(f"Thread: {thread_name} Count: {count}")
    
    # Stop the timer after 5 executions
    if count >= 5:
        timer.deinit()

# Initialize timers and start threads
timers = []
timers.append(Timer(0))
timers[0].init(period=1000, mode=Timer.PERIODIC, callback=lambda t: timer_thread(t, "Job_A", 1))

timers.append(Timer(1))
timers[1].init(period=2000, mode=Timer.PERIODIC, callback=lambda t: timer_thread(t, "Job_B", 2))

timers.append(Timer(2))
timers[2].init(period=3000, mode=Timer.PERIODIC, callback=lambda t: timer_thread(t, "Job_C", 3))

timers.append(Timer(3))
timers[3].init(period=4000, mode=Timer.PERIODIC, callback=lambda t: timer_thread(t, "Job_D", 4))

print("Main Thread: Start")
print("Main Thread: Sleep 30 seconds...")
time.sleep(30)

# Stop all timers after main thread finishes
for timer in timers:
    timer.deinit()

print("Main Thread: End")