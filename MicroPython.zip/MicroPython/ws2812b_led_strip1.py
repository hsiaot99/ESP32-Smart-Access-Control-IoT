from machine import Pin
import neopixel
import time

gpio = 15
num_leds = 8
p = Pin(gpio)
led_strip = neopixel.NeoPixel(p, num_leds)


def show_leds():
    for i in range(num_leds):
        led_strip[i] = (i * 5, (num_leds - i) * 5, 0)
        time.sleep_ms(500)
        led_strip.write()


def clear_leds():
    for i in range(num_leds):
        led_strip[i] = (0, 0, 0)
    led_strip.write()


show_leds()
time.sleep(3)
clear_leds()