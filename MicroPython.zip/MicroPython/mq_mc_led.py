from machine import Pin
from umqtt.simple import MQTTClient
import network, time, utime
 
mq_server = "broker.mqttgo.io"
mq_id = "mqsub_abcdef"
mq_topic = "maker/wenchin/command"
mq_user = "my_name"
mq_pwd = "my_password"

gpio_led = 2
pin_led = Pin(gpio_led, Pin.OUT)
 
def on_message(topic, payload):
    u_topic = topic.decode("utf-8")
    u_payload = payload.decode("utf-8")
    print("Received message on topic: [{}], message: [{}]".format(u_topic, u_payload))

    if u_payload == 'ON':
        pin_led.on()
    elif u_payload == 'OFF':
        pin_led.off()
 
 
# MQTT Connection
mqClient = MQTTClient(mq_id, mq_server, user=mq_user, password=mq_pwd)
mqClient.set_callback(on_message)
mqClient.connect()
mqClient.subscribe(mq_topic)
print("Subscribed Topic: {}".format(mq_topic))
 
while True:
    mqClient.check_msg()
    time.sleep_ms(200)