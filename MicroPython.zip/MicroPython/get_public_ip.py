import network, utime
import urequests

url0 = "http://ip.goomo.net/"
url1 = "https://www.goomo.net/ipaddress.php"
url2 = "http://worldtimeapi.org/api/timezone/asia/taipei"

# HTTP GET
r = urequests.get(url1)

print(r.status_code)
print(r.text)