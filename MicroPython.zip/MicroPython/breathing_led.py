from machine import Pin, PWM
import utime

gpio = 2
delay = 2
p = PWM(Pin(gpio, Pin.OUT))

while True:
    for i in range(1024):
        # 設置針腳輸出
        p.duty(i)
        utime.sleep_ms(delay)
    for i in range(1023, 0, -1):
        p.duty(i)
        utime.sleep_ms(delay)