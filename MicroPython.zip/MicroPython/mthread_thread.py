import _thread
import time
# Define a function for the thread
def thread_job( threadName, delay):
   for count in range(1, 6):
      time.sleep(delay)
      print(f"Thread: {threadName} Count: {count}")

# Create two threads as follows
try:
   _thread.start_new_thread( thread_job, ("Job_A", 1, ) )
   _thread.start_new_thread( thread_job, ("Job_B", 2, ) )
   _thread.start_new_thread( thread_job, ("Job_C", 3, ) )
   _thread.start_new_thread( thread_job, ("Job_D", 4, ) )
except:
   print("Error: unable to start thread")

#while True:
#   pass
print("Main Thread: Start")
print("Main Thread: Sleep 30 seconds...")
time.sleep(30)
print("Main Thread: End")