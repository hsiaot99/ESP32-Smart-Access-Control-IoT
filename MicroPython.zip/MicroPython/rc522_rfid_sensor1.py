from machine import Pin
import time
import mfrc522

# SPI for RC522 RFID / NFC 感應模組
gpio_ss = 5
gpio_sck = 18
gpio_mosi = 23
gpio_miso = 19
gpio_rst = 32  # ?

# for 內建 LED
gpio_led = 2


# 初始化
pin_led = Pin(gpio_led, Pin.OUT)

rfid = mfrc522.MFRC522(
    gpio_sck, gpio_mosi, gpio_miso, gpio_rst, gpio_ss
)  # SCLK  # MOSI  # MISO  # RST  # SDA (CS)


while True:
    id = rfid.getCardValue()
    if id:
        print("Tag ID:", id)
        pin_led.on()
        time.sleep_ms(500)
        pin_led.off()
    time.sleep_ms(500)