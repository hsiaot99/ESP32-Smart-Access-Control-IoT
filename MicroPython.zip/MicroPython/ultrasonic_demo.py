from machine import Pin
import time
import ultrasonic

gpio_trig = 16
gpio_echo = 17

pin_trig = Pin(gpio_trig, mode=Pin.OUT)
pin_echo = Pin(gpio_echo, mode=Pin.IN)

sensor = ultrasonic.Ultrasonic(pin_trig, pin_echo)

while True:
    try:
        d = sensor.distance_in_cm()
        print("Distance: {:.1f} cm".format(d))

    except ultrasonic.MeasurementTimeout as e:
        print("{}".format(e))

    time.sleep_ms(500)