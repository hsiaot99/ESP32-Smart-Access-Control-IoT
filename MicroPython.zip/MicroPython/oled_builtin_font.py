from machine import Pin, SoftI2C
import ssd1306

DISPLAY_WIDTH = 128   
DISPLAY_HEIGHT = 64
gpio_sda = 21
gpio_scl = 22

# create I2C interface
i2cbus = SoftI2C(sda=Pin(gpio_sda), scl=Pin(gpio_scl))
display = ssd1306.SSD1306_I2C(DISPLAY_WIDTH, DISPLAY_HEIGHT, i2cbus)

display.text('Hello, World!', 0, 0, 1)
display.text('MicroPython', 23, 45)     

display.show()