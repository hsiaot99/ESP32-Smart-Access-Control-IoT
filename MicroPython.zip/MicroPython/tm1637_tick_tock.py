import tm1637
from machine import Pin
import time

gpio_clk = 14
gpio_dio = 13

tm = tm1637.TM1637(clk=Pin(gpio_clk), dio=Pin(gpio_dio))

i = 1680
while True:
    s = "{:04d}".format(i)
    tm.show(s, True)
    time.sleep_ms(500)
    tm.show(s, False)
    time.sleep_ms(500)
    i = (i + 1) % 10000