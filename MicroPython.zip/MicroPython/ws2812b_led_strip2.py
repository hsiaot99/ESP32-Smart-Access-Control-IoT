from machine import Pin
import neopixel
import time
import random

gpio = 15
num_leds = 8
lightness = 16

p = Pin(gpio)
led_strip = neopixel.NeoPixel(p, num_leds)

try:
    while True:
        for i in range(num_leds):
            led_strip[i] = (
                random.randrange(0, lightness),
                random.randrange(0, lightness),
                random.randrange(0, lightness),
            )

        led_strip.write()
        time.sleep(1)

except KeyboardInterrupt:
    for i in range(num_leds):
        led_strip[i] = (0, 0, 0)  # 關燈

    led_strip.write()