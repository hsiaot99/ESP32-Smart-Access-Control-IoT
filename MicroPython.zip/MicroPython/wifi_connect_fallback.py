import network
import utime

wifi_ssid = "hsiao"
wifi_password = "hsiaoHot"

ap_essid = "ESP_hsiao"
ap_password = "ESP_AP_hsiao"

wifi = network.WLAN(network.STA_IF)

try:
    wifi.active(False)
    wifi.active(True)
    wifi.connect(wifi_ssid, wifi_password)  # wifi ssid and password
    print(f"開始連接 Wi-Fi: {wifi_ssid}")
    for i in range(20):
        print("嘗試於{}秒內連接WiFi".format(i))
        utime.sleep(1)
        if wifi.isconnected():
            break
    if wifi.isconnected():
        print("WiFi連接成功！")
        print("網路配置=", wifi.ifconfig())
    else:
        print("WiFi連接錯誤！改為 AP 模式！")
        wifi.active(False)
        ap = network.WLAN(network.AP_IF)
        ap.active(True)
        ap.config(essid=ap_essid, password=ap_password)
except Exception as e:
    print(e)