from machine import Pin, PWM
import time

gpio_buzzer = 4
gpio_button = 36

buzzer = PWM(Pin(gpio_buzzer), freq=262, duty=0)
button = Pin(gpio_button, Pin.IN, Pin.PULL_UP)


def doorbell():
    buzzer.duty(512)
    buzzer.freq(988)
    time.sleep(0.5)
    buzzer.freq(784)
    time.sleep(1)
    buzzer.duty(0)


while True:
    if not button():
        doorbell()
        time.sleep(0.5)