import asyncio

# Define an asynchronous thread function
async def thread_job(thread_name, delay):
    for count in range(1, 6):
        await asyncio.sleep(delay)
        print(f"Thread: {thread_name} Count: {count}")

# Define the main coroutine to run multiple threads concurrently
async def main():
    print("Main Thread: Start")
    threads = [
        thread_job("Job_A", 1),
        thread_job("Job_B", 2),
        thread_job("Job_C", 3),
        thread_job("Job_D", 4)
    ]
    
    # Run all threads concurrently
    await asyncio.gather(*threads)
    
    print("Main Thread: Sleep 30 seconds...")
    await asyncio.sleep(30)
    print("Main Thread: End")

# Run the main coroutine
asyncio.run(main())