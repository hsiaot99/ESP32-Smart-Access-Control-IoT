import network
import ubinascii

def mac2Str(mac): 
    return ':'.join([f"{b:02X}" for b in mac])

wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan_mac = wlan.config('mac')
wlan_mac_hex = ubinascii.hexlify(wlan_mac).decode()
wlan_mac_str1 = ubinascii.hexlify(wlan_mac, ':').decode()
wlan_mac_str2 = mac2Str(wlan_mac)

print("MAC Address:", wlan_mac)
print("MAC Address in HEX:", wlan_mac_hex)
print("MAC Address in HEX String:", wlan_mac_str1)
print("MAC Address in HEX String:", wlan_mac_str2)