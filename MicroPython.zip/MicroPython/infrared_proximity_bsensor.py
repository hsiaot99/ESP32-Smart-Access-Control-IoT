from machine import Pin
import time
 
gpio = 35
p = Pin(gpio, Pin.IN)
 
while True:
    v = p.value()
    print(f"Pin_{gpio}: {v}")
    time.sleep(1)