from machine import Pin
import dht
import time

gpio_dht = 33
 
d = dht.DHT11(Pin(gpio_dht))

while True:
    d.measure()
    t = d.temperature()
    h = d.humidity()
    print("溫度：{:d}°C ， 濕度：{:d}%".format(t, h))
    time.sleep(2)