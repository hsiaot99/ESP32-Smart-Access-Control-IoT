from machine import Pin, SoftI2C, PWM
import time
import mfrc522
import ssd1306

# for 無源蜂鳴器
gpio_buzzer = 4

# SPI for RC522 RFID / NFC 感應模組
gpio_ss = 5
gpio_sck = 18
gpio_mosi = 23
gpio_miso = 19
gpio_rst = 32  # ?

# I2C for SSD1306 OLED 顯示器
gpio_sda = 21
gpio_scl = 22
DISPLAY_WIDTH = 128
DISPLAY_HEIGHT = 64

# 初始化
rfid = mfrc522.MFRC522(
    gpio_sck, gpio_mosi, gpio_miso, gpio_rst, gpio_ss
)  # SCLK  # MOSI  # MISO  # RST  # SDA (CS)

i2cbus = SoftI2C(sda=Pin(gpio_sda), scl=Pin(gpio_scl))
oled = ssd1306.SSD1306_I2C(DISPLAY_WIDTH, DISPLAY_HEIGHT, i2cbus)
buzzer = PWM(Pin(gpio_buzzer), freq=1000, duty=0)


while True:
    id = rfid.getCardValue()
    if id:
        print("Tag ID:", id)

        oled.fill(0)
        oled.text("Tag ID:", 0, 0)
        oled.text(id, 0, 20)
        oled.show()
        
        buzzer.duty(512)
        time.sleep_ms(200)
        buzzer.duty(0)

    time.sleep_ms(500)