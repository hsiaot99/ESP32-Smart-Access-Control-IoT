from umqtt.simple import MQTTClient
import network, time, utime
import wifi_connect_fallback


mq_server = "broker.mqttgo.io"
mq_id = "mqsub_abcdef"
mq_topic = "maker/my_name"
mq_user = "my_name"
mq_pwd = "my_password"


def on_message(topic, payload):
    u_topic = topic.decode("utf-8")
    u_payload = payload.decode("utf-8")
    print("Received message on topic: [{}], message: [{}]".format(u_topic, u_payload))


# MQTT Connection
mqClient = MQTTClient(mq_id, mq_server, user=mq_user, password=mq_pwd)
mqClient.set_callback(on_message)
mqClient.connect()
mqClient.subscribe(mq_topic)
print("Subscribed Topic: {}".format(mq_topic))

while True:
    mqClient.check_msg()
    time.sleep_ms(200)