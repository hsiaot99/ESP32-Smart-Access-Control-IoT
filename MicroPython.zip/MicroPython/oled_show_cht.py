from machine import Pin, SoftI2C
import ssd1306
import framebuf
from oled_cht_fonts import font_size, font_list

DISPLAY_WIDTH = 128   
DISPLAY_HEIGHT = 64
gpio_sda = 21
gpio_scl = 22

i2cbus = SoftI2C(sda=Pin(gpio_sda), scl=Pin(gpio_scl))
display = ssd1306.SSD1306_I2C(DISPLAY_WIDTH, DISPLAY_HEIGHT, i2cbus)
display.fill(0)

for (i, f) in enumerate(font_list):
    buffer = bytearray(f)

    # Create a FrameBuffer for the image data
    fb = framebuf.FrameBuffer(buffer, 32, 32, framebuf.MONO_HLSB)  # Adjust to your image dimensions
    display.blit(fb, font_size * i, 0)

display.show()