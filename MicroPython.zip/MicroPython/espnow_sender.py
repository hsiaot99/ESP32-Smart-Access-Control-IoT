import network
import espnow
import ubinascii
import machine
import time

# Replace with your receiver's MAC address obtained earlier
receiver_mac = b'\xE0\x5A\x1B\xD1\x10\xB4'  # Example MAC address
#receiver_mac = b'\xEC\x64\xC9\x5E\xEC\x18'  # Example MAC address

broadcast_mac = b'\xff\xff\xff\xff\xff\xff'
#receiver_mac = broadcast_mac

def mac2Str(mac): 
    return ':'.join([f"{b:02X}" for b in mac])

# Initialize the Wi-Fi in station mode
wlan = network.WLAN(network.STA_IF)
wlan.active(True)

# Initialize ESP-NOW
e = espnow.ESPNow()
e.active(True)
wlan_mac = wlan.config('mac')
wlan_mac_hex = ubinascii.hexlify(wlan_mac, ':').decode()

# Add the receiver as a peer
e.add_peer(receiver_mac)
receiver_mac_str = mac2Str(receiver_mac)
print(f"Ready to send messages to Receiver {receiver_mac_str}")

# Function to send a message
def send_message(msg):
    try:
        e.send(receiver_mac, msg.encode('utf-8'))
        print("Sent: {}".format(msg))
    except Exception as ex:
        print("Failed to send message: {}".format(ex))

# Example: Send a message every 5 seconds
while True:
    now = time.localtime()
    now_str = f"{now[3]}:{now[4]:02d}:{now[5]:02d}"
    message = f"Hello from ESP32 Sender ({wlan_mac_hex} @ {now_str})"
    send_message(message)
    time.sleep(5)