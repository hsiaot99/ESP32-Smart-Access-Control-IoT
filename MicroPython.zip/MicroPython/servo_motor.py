# servo_motor.py

import machine
import utime

pinID = 16 # GPIO pin ID
freq = 50  # Set the pulse every 20ms
nap_default = 60 # millisecond
duty_up = 56
duty_down = 110
duty_mid = 83  # Set default PWM duty = 45 degrees
duty = duty_mid

"""
# Creates a function for mapping the 0 to 180 degrees to 20 to 120 pwm duty values
def map(x, in_min, in_max, out_min, out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

# Creates another function for turning the servo according to input angle
def servo(motor, angle):
    motor.duty(map(angle, 0, 180, 25, 115))
"""

# Step-by-step moving
def moveto_duty(a, nap=nap_default):
    global duty
    if (a > duty):
        while (a > duty):
            duty += 1
            print(duty)
            pwm.duty(duty)
            utime.sleep_ms(nap)
    elif (a < duty):
        while (a < duty):
            duty -= 1
            print(duty)
            pwm.duty(duty)
            utime.sleep_ms(nap)
    pwm.duty(0)


# Create a regular GPIO object
pin = machine.Pin(pinID, machine.Pin.OUT)

# Create another object named pwm by attaching the pwm driver to the pin
pwm = machine.PWM(pin, freq)

# Go to the default position
pwm.duty(duty_mid)
utime.sleep_ms(500)

# Rotate Testing
moveto_duty(duty_down)
utime.sleep_ms(500)

moveto_duty(duty_up, 30)
utime.sleep_ms(500)

# Back to the default position
moveto_duty(duty_mid, 15)