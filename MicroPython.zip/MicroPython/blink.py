# 修正版 @ 2023-10-18
from machine import Pin
import time

id = 2
p = Pin(id, Pin.OUT)

# while True:
for i in range(10):
    p.on()
    print(f"Pin_{id}: High")
    time.sleep(1)
 
    p.off()
    print(f"Pin_{id}: Low")
    time.sleep(1)