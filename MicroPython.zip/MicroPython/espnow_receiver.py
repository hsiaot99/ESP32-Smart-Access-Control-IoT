import network
import espnow
import ubinascii
import machine

# Initialize the Wi-Fi in station (STA) mode
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan_mac = wlan.config('mac')
wlan_mac_str = ubinascii.hexlify(wlan_mac, ':').decode()
print("Receiver MAC Address:", wlan_mac_str)

# Initialize ESP-NOW
e = espnow.ESPNow()  # `init()` not required
e.active(True)

print("ESP-NOW Receiver is running and listening for messages...")

# Keep the script running
while True:
    #machine.idle()
    try:
        mac, msg = e.recv()  # `recv()` will block until a message is received
        if msg:
            mac_str = ubinascii.hexlify(mac, ':').decode()
            print('Received from {} ~ {}'.format(mac_str, msg.decode()))
    except OSError:
        pass  # Handle cases where no message is received (non-blocking call)