from umqtt.simple import MQTTClient
import network, time, utime

mq_server = "broker.mqttgo.io"
mq_id = "mqpub_abcdef"
mq_topic = "maker/my_name"
mq_user = "my_name"
mq_pwd = "my_password"

# MQTT Connection
mqClient = MQTTClient(mq_id, mq_server, user=mq_user, password=mq_pwd)
mqClient.connect()

for i in range(3):
    payload = "您好，Hello {}".format(i)
    mqClient.publish(mq_topic, payload.encode("utf-8"))
    print("已發佈訊息【{}】".format(payload))
    time.sleep(1)