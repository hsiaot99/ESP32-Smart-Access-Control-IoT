from machine import Pin, PWM
import utime

gpio_servo = 27

servo = PWM(Pin(gpio_servo, mode=Pin.OUT))
servo.freq(50)

# 0.5ms/20ms = 0.025 = 2.5% duty cycle
# 2.4ms/20ms = 0.12 = 12% duty cycle

# 0.025*1024=25.6
# 0.12*1024=122.88

for i in range(3):
    servo.duty(45)  # >= 26
    utime.sleep(1)
    servo.duty(95)  # <= 123
    utime.sleep(1)
    
servo.duty(53)      # about 75