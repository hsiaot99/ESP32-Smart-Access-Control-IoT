from machine import Pin, PWM
import time

gpio_buzzer = 4

buzzer = PWM(Pin(gpio_buzzer), freq=262, duty=0)


def buzz(frequency, duration):
    buzzer.duty(512)
    buzzer.freq(frequency)
    time.sleep(duration)
    buzzer.duty(0)


for freq in [262, 330, 392, 523]:  # C 分散和弦
    buzz(freq, 0.5)  # 每個音符播放 0.5 秒
    time.sleep_ms(100)