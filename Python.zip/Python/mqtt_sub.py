'''
mqtt_sub.py
version: 2.0  @2024-12-02
Wenchin Hsieh @Goomo.Net Studio, wenchin@goomo.net
References: 
'''

import sys, msvcrt, time
import paho.mqtt.client as mqtt


# 參數設定
#mqtt_server = "test.mosquitto.org"
mqtt_server  = "broker.mqttgo.io"
#mqtt_user   = "my_name"
#mqtt_pwd    = "my_password"
mqtt_topic   = "mcuiot/hsiao"
topic_ALL    = "mcuiot/hsiao/#"
MQTT_LOOP_Interval = 0.05 


# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc, properties):
    print("Connected with result code "+str(rc))
 
    # Subscribing in on_connect() means that if we lose the connection and reconnect then subscriptions will be renewed.
    client.subscribe(mqtt_topic)
    #client.subscribe(topic_ALL)

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    #mp = msg.payload.decode('ascii')
    mp = msg.payload.decode('utf-8')
    print("TOPIC: [" + msg.topic + "], MESSAGE: " + mp + "]")


# MQTT 連線準備
mqclient = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
mqclient.on_connect = on_connect
mqclient.on_message = on_message
#mqclient.username_pw_set(username=MQTT_USER, password=MQTT_PWD)  # 若無需使用者帳密，則直接刪除本行！
mqclient.connect_async(mqtt_server, 1883, 60)  #  連結 MQTT Server，指定以 非同步模式 執行 MQTT Message 傳入檢查。
mqclient.loop_start()    


# MQTT Subscribe ，同時等待使用者按 ESC 退出
print("\n按下 [Esc]鍵 可結束程式 !\n", ) 
 
while True:
    #mqclient.loop()      # 無需執行 等待式檢查，已由 loop_async() 非同步模式 取代。
    if msvcrt.kbhit():  # Key Pressed
        if msvcrt.getch() == b'\x1b':  # [Esc] Key
            break
    time.sleep(MQTT_LOOP_Interval)


# Release All Handlers 以結束程式 
mqclient.loop_stop()
mqclient.disconnect()