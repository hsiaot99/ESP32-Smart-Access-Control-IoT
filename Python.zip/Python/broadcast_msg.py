import requests

LINE_CHANNEL_ACCESS_TOKEN = 'YypyDEScoGMS8qjuvZsNWoM92/6d1WY7L+eACwYN4MeqtCNz73iWkKbx9KxOLmZafgshX13k9JGxW14fEjGQrl8LZMS9VQCuf7nQLKaEX6Anw05/h9TqpWUxW+5nQ7E7qmQJ1bgndmLKYuBPLDTZngdB04t89/1O/w1cDnyilFU='

def broadcast_message(message):
    url = "https://api.line.me/v2/bot/message/broadcast"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LINE_CHANNEL_ACCESS_TOKEN}"
    }
    data = {
        "messages": [
            {
                "type": "text",
                "text": message
            }
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        print("Message broadcasted successfully!")
    else:
        print(f"Failed to broadcast: {response.status_code}, {response.text}")

# Example usage
broadcast_message("Hello, everyone! This is a broadcast message.")