import pygame
from pygame.locals import QUIT

pygame.init()
pygame.font.init()

# 列出當前系統所有可用字型
#print(pygame.font.get_fonts())


# 渲染字型
def render_text(f, t, s=72, c=(255, 255, 0), b=False, i=False):
    myfont = [
        pygame.font.SysFont("microsoftjhenghei", s, bold=b, italic=i),  # 微軟正黑體 （含:繁/簡/日）
        pygame.font.SysFont("microsoftyahei", s, bold=b, italic=i),     # 微軟雅黑體 （含:繁/簡/日）
        pygame.font.SysFont("mingliu", s, bold=b, italic=i),            # 新細明體 （含:繁/簡/日）
        pygame.font.SysFont("simsun", s, bold=b, italic=i),             # 新宋體 （含:繁/簡/日）
        pygame.font.SysFont("dfkaisb", s, bold=b, italic=i),            # 標楷體 （含:繁/簡/日）
        #pygame.font.SysFont("Arial", s, bold=b, italic=i),
        #pygame.font.SysFont("twcen", s, bold=b, italic=i),
    ]
    text = myfont[f].render(t, True, c)
    return text


# Text to be rendered with render_text
game_over = render_text(4, "GAME 遊戲結束 Over!")
restart = render_text(1, "按「空白鍵」重玩！", 36, (9, 228, 180))

SURF = pygame.display.set_mode((600, 400))
loop = True
clock = pygame.time.Clock()
while loop == True:
    SURF.fill((0, 0, 0))
    x, y = pygame.mouse.get_pos()
    SURF.blit(game_over, (100, 150))
    SURF.blit(restart, (x, y))
    for e in pygame.event.get():
        if e.type == QUIT:
            loop = 0
    pygame.display.update()
    clock.tick(60)

pygame.quit()