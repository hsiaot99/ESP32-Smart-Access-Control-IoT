# FontMap_2bw.py

from os import environ
environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

import pygame

my_text = "歡迎光臨"
#use_ttf = 1  # (32 x 43)
use_ttf = 3  # (32 ~ 50 x 32)
font_size = 32
font_color = (255, 255, 255)

ttf = [
    "microsoftjhenghei",  # 微軟正黑體 （含:繁/簡/日）
    "microsoftyahei",     # 微軟雅黑體 （含:繁/簡/日）
    'mingliu',            # 新細明體 （含:繁/簡/日）
    'dfkaisb',            # 標楷體 （含:繁/簡/日）
    'simsun',             # 新宋體 （含:繁/簡/日）
]

def dump_font_2bw(canvas, x1, y1, x2, y2):
    for y in range(y1, y2):
        for x in range(x1, x2):
            pixel = canvas.get_at((x, y))
            if pixel[3] >= 127:
                print('🟤', end='')
            else:
                print('⚪', end='')
        print()
    print()


# Init PyGame
pygame.font.init()
font = pygame.font.SysFont(ttf[use_ttf], font_size)

# 繪製第一個字 @ canvas
txt0 = my_text[0]
canvas = font.render(txt0, True, font_color)
w = canvas.get_width()
h = canvas.get_height()
x1 = (w - font_size)
y1 = (h - font_size) * 2 // 3

# 全圖（非正方形，含空白間隔）
print("\n", (w, h))
dump_font_2bw(canvas, 0, 0, w, h)

# 字型圖（正方形，無空白間隔）
print("\n", (font_size, font_size))
dump_font_2bw(canvas, x1, y1, x1 + font_size, y1 + font_size)