import sys
import time
import pygame
from pygame.locals import QUIT

use_bg_img  = False
bg_color    = (8, 72, 64)
font_color  = (255, 223, 33)
time_sleep  = 0.008

ttf = [
    "microsoftjhenghei",  # 微軟正黑體 （含:繁/簡/日）
    "microsoftyahei",     # 微軟雅黑體 （含:繁/簡/日）
    'mingliu',            # 新細明體 （含:繁/簡/日）
    'dfkaisb',            # 標楷體 （含:繁/簡/日）
    'simsun',             # 新宋體 （含:繁/簡/日）
]

use_ttf = 1
txt_caption = "PyGame 多行中文字型跑馬燈"
txt_marquee = " ABC xyz \n 繁體動畫發售 \n 简体动画发售 \n 日本動画発売 \n あいうえお ！"
max_line    = " あいうえお ！"

pygame.init()
pygame.display.set_caption(txt_caption)
sx, sy = 320, 50
screen = pygame.display.set_mode((640, 480), 0, 32)
# print(pygame.font.get_fonts()) # 列出當前系統所有可用字型

def render_multi_line(text, x, y, fsize):
    lines = text.splitlines()
    for i, t in enumerate(lines):
        screen.blit(sys_font.render(t, True, font_color), (x, y + fsize*i))

# 主程式
if use_bg_img:
    background = pygame.image.load("bg.jpg").convert()

while True:
    for fs in (64, 32, 16):
        sys_font = pygame.font.SysFont(ttf[use_ttf], fs)
        x, y = sx, sy
        max_surface = sys_font.render(max_line, True, font_color)
        max_width = max_surface.get_width()

        while x > - max_width:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()

            if use_bg_img:
                screen.blit(background, (0, 0))
            else:
                screen.fill(bg_color)

            render_multi_line(txt_marquee, x, y, fs)
            pygame.display.update()
            time.sleep(time_sleep)
            x -= 1