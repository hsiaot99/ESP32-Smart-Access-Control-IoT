# FontDump_File4Py.py
# @ cmd
# python FontDump_File4Py.py > oled_cht_fonts.py

from os import environ
environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

import pygame

my_text = "歡迎光臨"
#use_ttf = 1  # (32 x 43)
use_ttf = 3  # (32 ~ 50 x 32)
font_size = 32
font_color = (255, 255, 255)

ttf = [
    "microsoftjhenghei",  # 微軟正黑體 （含:繁/簡/日）
    "microsoftyahei",     # 微軟雅黑體 （含:繁/簡/日）
    'mingliu',            # 新細明體 （含:繁/簡/日）
    'dfkaisb',            # 標楷體 （含:繁/簡/日）
    'simsun',             # 新宋體 （含:繁/簡/日）
]


def dump_font_ds(canvas, x1, y1, x2, y2):
    for y in range(y1, y2):
        print(' ' * 4, end='')
        for x in range(x1, x2, 8):
            x_byte = 0
            for s in range(0, 8):
                pixel = canvas.get_at((x + s, y))
                x_bit = 1 if pixel[3] >= 127 else 0
                x_byte += x_bit << (7 - s)
            print(f"0x{x_byte:02x}, ", end='')
        print()


# Init PyGame
pygame.font.init()
font = pygame.font.SysFont(ttf[use_ttf], font_size)

# 製作字型資料檔案（oled_cht_fonts.py）
print(f'# {my_text} @ {ttf[use_ttf]}\n')
print(f'font_size = {font_size}\n')
for (i, t) in enumerate(my_text):
    print(f'# {t}\nfont_{i} = [')
    canvas = font.render(t, True, font_color)
    w = canvas.get_width()
    h = canvas.get_height()
    x1 = (w - font_size)
    y1 = (h - font_size) * 2 // 3
    dump_font_ds(canvas, x1, y1, x1 + font_size, y1 + font_size)
    print(']\n')

print('font_list = [')
for i in range(len(my_text)):
    print(f'    font_{i},')
print(']\n')