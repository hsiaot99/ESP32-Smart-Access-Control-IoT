#import network, utime
import socket
import wifi_connect_fallback.py

socket_server = "192.168.137.100"
socket_port = 12345

# Create a socket object and connect to server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
address = (socket_server, socket_port)
sock.connect(address)

# Receive data from the socket server
data_recv = sock.recv(1024)  # 1024 is the buffer size
print(f"Received from server: {data_recv.decode()}")

# Send a message to the socket server
message = input("Input the message to send: (keep empty to stop server!) ")
sock.send(message.encode())

# Close the socket
sock.close()