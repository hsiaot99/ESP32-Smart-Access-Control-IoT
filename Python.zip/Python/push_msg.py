import requests

LINE_CHANNEL_ACCESS_TOKEN = 'YypyDEScoGMS8qjuvZsNWoM92/6d1WY7L+eACwYN4MeqtCNz73iWkKbx9KxOLmZafgshX13k9JGxW14fEjGQrl8LZMS9VQCuf7nQLKaEX6Anw05/h9TqpWUxW+5nQ7E7qmQJ1bgndmLKYuBPLDTZngdB04t89/1O/w1cDnyilFU='
LINE_USER_ID = "YOUR_USER_ID"

def send_message_to_user(user_id, message):
    url = "https://api.line.me/v2/bot/message/push"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LINE_CHANNEL_ACCESS_TOKEN}"
    }
    data = {
        "to": user_id,
        "messages": [
            {
                "type": "text",
                "text": message
            }
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        print(f"Message sent to user {user_id} successfully!")
    else:
        print(f"Failed to send message: {response.status_code}, {response.text}")

# Example usage
send_message_to_user(LINE_USER_ID, "Hello! This is a message just for you!")