from os import environ
environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

import pygame

font_size  = 30
font_color = (255, 223, 33)

ttf = [
    "microsoftjhenghei",  # 微軟正黑體 （含:繁/簡/日）
    "microsoftyahei",     # 微軟雅黑體 （含:繁/簡/日）
    'mingliu',            # 新細明體 （含:繁/簡/日）
    'dfkaisb',            # 標楷體 （含:繁/簡/日）
    'simsun',             # 新宋體 （含:繁/簡/日）
]

use_ttf = 3
txt_caption  = "擷取字型BitMap圖檔"
txt_marquee  = "怪博士沒課智慧訊息背包★"


def dump_font_4grey(x1, y1, x2, y2):
    for y in range(y1, y2):
        for x in range(x1, x2):
            rgbt = canvas.get_at((x, y))
            if rgbt[3] == 255:
                print('⬜', end='')
            elif rgbt[3] == 0:
                print('．', end='')
            elif rgbt[3] >= 127:
                print('◻️', end='')
            else:
                print('◽', end='')
        print()


# pygame.init()
pygame.font.init()
font = pygame.font.SysFont(ttf[use_ttf], font_size)

f = txt_marquee[0]
canvas = font.render(f, True, font_color)

# 全圖（非正方形，含空白間隔）
cx = canvas.get_width()
cy = canvas.get_height()
print("\n", (cx, cy))
dump_font_4grey(0, 0, cx, cy)

# 字型圖（正方形，無空白間隔）
print("\n", (font_size, font_size))
fx = (cx - font_size)
fy = (cy - font_size) // 2
dump_font_4grey(fx, fy, fx + font_size, fy + font_size)