import cv2

# Android: Video resolution = 640x480 , FPS Limit = 10
# rtsp = 'rtsp://192.168.137.204.yyy:8080/h264_ulaw.sdp'
#rtsp = 'rtsp://user:password@192.168.xxx.yyy:8080/h264_ulaw.sdp'

# iPhone: 解析度 = 640x480 , 偵率 = 10
rtsp = 'rtsp://admin:admin@192.168.137.204:8554/live'


skipFrame = 1
cap = cv2.VideoCapture(rtsp)

while True:
    for i in range(skipFrame):
        cap.grab()                      # 快轉跳過

    ret, frame = cap.retrieve()         # 讀取下一個 frame

    if ret:
        cv2.imshow('rtsp2show', frame)

    if cv2.waitKey(1) & 0xFF in [27, ord('Q'), ord('q')]:
        break

cap.release()
cv2.destroyAllWindows()