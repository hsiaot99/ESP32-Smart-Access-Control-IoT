'''
mqtt_pub.py
version: 1.3  @2022/10/18
Wenchin Hsieh @Goomo.Net Studio, wenchin@goomo.net
References: 
'''

import sys
import paho.mqtt.client as mqtt


# 參數設定
#mqtt_server = "test.mosquitto.org"
mqtt_server  = "broker.mqttgo.io"
#mqtt_user   = "my_name"
#mqtt_pwd    = "my_password"
mqtt_topic   = "mcuiot/hsiao"


# MQTT 連線準備
mqclient = mqtt.Client()
#mqclient.username_pw_set(username=mqtt_user, password=mqtt_pwd)  # 若無需使用者帳密，則直接刪除本行！
if mqclient.connect(mqtt_server, 1883, 60) == 0:
    print("MQTT Server Connected: {}\n".format(mqtt_server))
else:
    print("Fail to Connect MQTT Server: {}\n".format(mqtt_server))
    sys.exit()


# MQTT Publish                
while True:
    message = input('(輸入 Q 可離開) FaceID = ')
    if len(message) and (message not in 'qQ'):
        info = mqclient.publish(mqtt_topic, message)
    else:
        break

# Release All Handlers
mqclient.disconnect()