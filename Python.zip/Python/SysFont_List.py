import pygame

pygame.font.init()

# 列出當前系統所有可用字型
print(pygame.font.get_fonts())

for f in pygame.font.get_fonts():
    print(f)