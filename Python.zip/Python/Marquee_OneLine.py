import sys
import time
import pygame
from pygame.locals import QUIT

use_bg_img  = False
bg_color    = (8, 72, 64)
font_color  = (255, 223, 33)
time_sleep  = 0.002

ttf = [
    "microsoftjhenghei",  # 微軟正黑體 （含:繁/簡/日）
    "microsoftyahei",     # 微軟雅黑體 （含:繁/簡/日）
    'mingliu',            # 新細明體 （含:繁/簡/日）
    'dfkaisb',            # 標楷體 （含:繁/簡/日）
    'simsun',             # 新宋體 （含:繁/簡/日）
]

use_ttf = 1
txt_caption = "PyGame 單行中文字型跑馬燈"
txt_marquee = "ABC xyz 繁體動畫發售 简体动画发售 日本動画発売 あいうえお ！"

pygame.init()
pygame.display.set_caption(txt_caption)
sx = 320
screen = pygame.display.set_mode((640, 480), 0, 32)
# print(pygame.font.get_fonts()) # 列出當前系統所有可用字型

if use_bg_img:
    background = pygame.image.load("bg.jpg").convert()

while True:
    for fs in (64, 32, 16):
        font = pygame.font.SysFont(ttf[use_ttf], fs)
        text_surface = font.render(txt_marquee, True, (255, 223, 33))
        text_width = text_surface.get_width()
        x = sx
        y = (480 - text_surface.get_height()) // 2

        while x > - text_width:
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()

            if use_bg_img:
                screen.blit(background, (0, 0))
            else:
                screen.fill(bg_color)

            screen.blit(text_surface, (x, y))
            pygame.display.update()
            time.sleep(time_sleep)
            x -= 1